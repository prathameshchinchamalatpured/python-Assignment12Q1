from django.urls import path
from ecommapp import views

urlpatterns = [
    path('',views.index)
]